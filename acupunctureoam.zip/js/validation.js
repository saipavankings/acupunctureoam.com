

/* Mobile and Name Validation */

$(document).ready(function(){
    var enquiry_name_error = true;
    var phone_number_error = true;

    $('#enquiry_name').on('focusout', function(){
        enquiryName();
    });

    function enquiryName(){
        var val = $('#enquiry_name').val();
        if (/^[A-Za-z\s]+$/.test(val)) {
            // value is ok, use it
        } else {
            alert("Invalid Name. Must be Alphabet");
            // document.getElementById("enquiry_name").focus();
            enquiry_name_error = false;
            return false;
        }
    }

    $('#enquiry_mobile').on('focusout', function(){
        phoneNumber();
    });

    function phoneNumber(){
        var val = $('#enquiry_mobile').val();
        if (/^[6-9]\d{9}$/.test(val)) {
            // value is ok, use it
        } else {
            alert("Invalid number. Must be ten digits and starts with 6, 7, 8 & 9");
            // document.getElementById("enquiry_mobile").focus();
            phone_number_error = false;
            return false;
        }
    }

    $('#submit_button').click(function(event){

        
        enquiry_name_error = true;
        phone_number_error = true;

        phoneNumber();
        enquiryName();

        if((enquiry_name_error == true)&&(phone_number_error == true)){

            $("#enquiry_form").submit();

        }
        else {
            return false;
        }


    });
    
});


/* Mobile and Name Validation */